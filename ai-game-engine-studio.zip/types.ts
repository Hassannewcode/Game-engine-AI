export type WorkspaceType = '2D' | '3D';
