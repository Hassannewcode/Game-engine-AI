import React, { useRef, useEffect } from 'react';

interface GamePreviewProps {
    htmlContent: string;
}

const GamePreview: React.FC<GamePreviewProps> = ({ htmlContent }) => {
    const iframeRef = useRef<HTMLIFrameElement | null>(null);

    useEffect(() => {
        const iframe = iframeRef.current;
        if (!iframe) return;
        
        // Use srcdoc to safely and effectively render the full HTML string
        iframe.srcdoc = htmlContent;

    }, [htmlContent]);

    return (
        <iframe
            ref={iframeRef}
            title="Game Preview"
            sandbox="allow-scripts allow-same-origin" // allow-same-origin is needed for modules in sandboxed iframes
            className="w-full h-full border-0"
        />
    );
};

export default GamePreview;